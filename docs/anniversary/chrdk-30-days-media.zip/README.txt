CHRDK — 30 дней

10 карточек JPEG (качество 95), 1600×900.
01–05 — краткие итоги разработки.
06–10 — техническая статистика.

Методика технических чисел:
- период истории: 11 октября — 10 ноября 2026 года;
- 1 102 коммита в main, из них 1 036 без merge;
- 61 Pull Request влит в main за этот период;
- 166 опубликованных GitHub Releases: 150 stable и 16 prerelease;
- 222 597 строк Java + Python в снимке v1.5.3: 212 672 Java и 9 925 Python;
- 1 225 аннотаций @Test и 1 376 Java-файлов в снимке v1.5.3;
- 22 общих JAR, отдельные VK и Disasters, API 42, Purpur 26.3, Java 25.

https://github.com/cherdakmd/CHRDK_F_REGISTER
