# Руководство по импорту и риггингу модели в Live2D Cubism → VTube Studio

Модель полностью подготовлена по стандартам **Live2D Cubism 4.x / 5.x** в цветовом профиле **RGB 8-bit**, разрешение холста **`1776 × 2368 px`** (симметричный анфас `0°`, ось симметрии `X = 888 px`), с **прорисовкой скрытых областей (Back-fill / Inpainting)** без дыр под чёлкой, глазами, бровями, бородой, подбородком и рукавами.

---

## Состав пакета (`vtube_model/`)

| Файл / папка | Назначение |
| :--- | :--- |
| **`vtuber_model_live2d.psd`** | **Главный многослойный файл для Live2D Cubism** (`1776×2368`, RGB 8-bit, **14 групп / 57 слоёв**) |
| **`vtuber_character_transparent.png`** | Полноразмерный рендер персонажа на прозрачном фоне без белого ореола (`1776×2368 RGBA`) |
| **`live2d_layer_breakdown_sheet.png`** | Визуальная карта разбора слоёв и проверки дорисованных зон (Back-fill) |
| **`vtuber_avatar.veadomini`** | Готовый файл аватара для **Veadotube Mini** (можно стримить сразу без риггинга!) |
| **`vtuber_pngtuber_pack.zip`** | Архив со всеми 6 прозрачными PNG-состояниями (открытые/закрытые глаза, разговор, очки, румянец) + `.veadomini` |
| **`sprites/`** | Отдельные PNG-спрайты `1776×2368` для OBS Reactive / Discord Reactive / Veadotube |
| **`layers/` + `layers_manifest.json`** | Все 57 обрезанных слоёв с точными координатами и пивотами суставов |
| **`studio/`** | Локальное веб-приложение **Live2D Rig Simulator + PSD Layer Inspector + OBS Tracker** |

---

## Иерархия групп и слоёв в `vtuber_model_live2d.psd`

> **Примечание по сторонам (`L` / `R`):** В соответствии со стандартом **Live2D Cubism / VTube Studio**, `L` — левая сторона самого персонажа (справа для зрителя, `X > 888`), `R` — правая сторона персонажа (слева для зрителя, `X < 888`).

### 1. `01_Expressions_FX` *(дополнительные эмоции и аксессуары — по умолчанию скрыты)*
Настройте их на параметры переключения (`0 → 1`) для горячих клавиш `F1–F6` в **VTube Studio**:
- `Prop_Cool_Sunglasses` — тёмные очки с бликами (`Hotkey 1`)
- `FX_Sparkle_Stars` — звёздочки в глазах (`Hotkey 2`)
- `FX_Angry_Mark` — аниме-значок злости на виске (`Hotkey 3`)
- `FX_Sweatdrop` — капля пота на виске (`Hotkey 4`)
- `FX_Blush_Cheeks` — румянец на щеках (`Hotkey 5`)
- `FX_Gloom_Shadow` *(режим наложения `Multiply`)* — тень шока на лбу (`Hotkey 6`)

### 2. `02_Hair_Front` *(передние волосы под многозвенную физику маятника)*
- `Hair_Topknot` — фирменный пучок на макушке (`Pivot: X=888, Y=276`) — привяжите отдельный маятник физики `HairTop`!
- `Hair_Front_Center` — центральная прядь и основание макушки (дорисовано под пучком)
- `Hair_Front_L` / `Hair_Front_R` — левая и правая пряди чёлки
- `Hair_Side_L` / `Hair_Side_R` — височные пряди вдоль ушей

### 3. `03_Eyebrows` *(брови без подложки кожи — чистая альфа)*
- `Brow_L` / `Brow_R` — привяжите к `ParamBrowLY` / `ParamBrowRY`, `ParamBrowLAngle` / `ParamBrowRAngle`, `ParamBrowLForm` / `ParamBrowRForm`.

### 4–5. `04_Eye_L` и `05_Eye_R` *(полный стек клиппинга глаз Live2D)*
Настройка **Clipping ID** в инспекторе Live2D Cubism:
1. Выделите слой **`Sclera_L`** → скопируйте его ArtMesh ID (например, `ArtMesh_Sclera_L`).
2. Выделите **`Iris_L`** и **`Eye_Highlight_L`** → вставьте ID `Sclera_L` в поле **`Clipping`**!
3. Аналогично вставьте ID **`Sclera_R`** в поле **`Clipping`** у слоёв **`Iris_R`** и **`Eye_Highlight_R`**.
4. Привязка параметров:
   - `Iris_L` / `Iris_R` → Warp Deformer `ParamEyeBallX`, `ParamEyeBallY` (радужка полностью дорисована по овалу для свободного движения взгляда).
   - `Eye_Highlight_L` / `Eye_Highlight_R` → микро-физика дрожания блика при моргании.
   - `Eyelash_Upper_L/R`, `Eyelash_Lower_L/R`, `Sclera_L/R` → деформация моргания `ParamEyeLOpen` / `ParamEyeROpen` (`1.0` = открыт, `0.0` = закрыт; слои `Eye_Closed_L/R` служат точным референсом/переключением закрытой ресницы).

### 6–7. `06_Nose` и `07_Mouth_And_Beard` *(нос, усы, борода и рот)*
- `Nose` — смещение по `ParamAngleX` (`±8 px`) даёт выразительный 3D-параллакс лица.
- `Mustache` — изолированные усы над верхней губой: привяжите к `ParamMouthForm` (изгиб улыбки) и `ParamMouthOpenY`.
- `Beard_Chin` — изолированная борода/щетина на подбородке: привяжите к деформеру нижней челюсти, чтобы при открытии рта борода двигалась синхронно с подбородком.
- **Клиппинг открытого рта (`ParamMouthOpenY`)**:
  - Скопируйте ArtMesh ID слоя **`Mouth_Inside`** и вставьте его в **`Clipping`** для слоёв **`Tongue`**, **`Teeth_Upper`** и **`Teeth_Lower`**.
  - При `ParamMouthOpenY = 0.0` отображается `Mouth_Closed`; при открытии `> 0.08` плавно открывается `Mouth_Inside` + `Lip_Upper_Line` / `Lip_Lower_Line` (либо готовый слой `Mouth_Open_Happy_Ref`).

### 8–9. `08_Head_And_Ears` и `09_Neck`
- `Head_Face_Base` — полностью чистая кожа головы и лба без вырезов; при повороте головы и раскачке чёлки не возникает пустот.
- `Ear_L` / `Ear_R` — уши с запасом внутрь под голову (`ParamAngleX`: ближнее ухо слегка выдвигается, дальнее заходит за щёку).
- `Head_Shadow_On_Neck` (`Multiply`) + `Neck_Extended` — шея продлена высоко под подбородок (`Y = 668 px`) для наклона головы вверх (`ParamAngleY = +30`).

### 10–12. `10_Arms`, `11_Torso_Outfit`, `12_Lower_Body_And_Back_Hair`
- **Суставы рук (`Arm_L` / `Arm_R`)**: разделены на `Upper_Arm`, `Forearm` и `Hand` с круговыми нахлёстами в плече (`Y=985`), локте (`Y=1465`) и запястье (`Y=1910`) под `Rotation Deformer`.
- **Безрукавный торс (`Jacket_Panel_L/R`, `Jacket_Lapel_L/R`, `Inner_White_Shirt`)**: бока куртки полностью прорисованы под рукавами — руки можно свободно отводить в стороны без разрывов контура.
- **`Hair_Back`**: задний слой волос для обратного параллакса по `ParamAngleX / ParamAngleY`.

---

## Быстрый экспорт в VTube Studio

1. Откройте **Live2D Cubism Editor** → перетащите **`vtuber_model_live2d.psd`** в окно редактора (`File -> Open`).
2. Нажмите **Auto Mesh Generator (`Ctrl + Shift + G`)** → выберите пресет **Standard** или **Heavy** (для чёлки, бровей, ресниц и `Head_Face_Base`).
3. Создайте иерархию деформеров (`Body XYZ -> Neck -> Head XYZ -> Eyes / Mouth / Hair Physics`) и настройте физику в `Modeling -> Open Physics / Scene Blending Settings`.
4. Экспортируйте готовую модель: **`File -> Export For Runtime -> Export as moc3 file...`** (отметьте `Export Physics Settings` и `Generate texture atlas 2048x2048` или `4096x4096`).
5. Скопируйте папку с `.model3.json` и `.moc3` в:
   `Steam/steamapps/common/VTube Studio/VTube Studio_Data/StreamingAssets/Live2DModels/`.
