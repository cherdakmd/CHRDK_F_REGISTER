function incendium:admin/menu
