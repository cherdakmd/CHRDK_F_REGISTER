playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 0.749154 1
scoreboard players set @s nbs_borderofli_t 2