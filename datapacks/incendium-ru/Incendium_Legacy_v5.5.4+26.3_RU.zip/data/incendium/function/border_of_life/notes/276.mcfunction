playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.667420 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 1 1.334840 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 1.414214 1
scoreboard players set @s nbs_borderofli_t 276