playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 1 1.189207 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.000000 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 2.000000 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 1.498307 1
scoreboard players set @s nbs_borderofli_t 46