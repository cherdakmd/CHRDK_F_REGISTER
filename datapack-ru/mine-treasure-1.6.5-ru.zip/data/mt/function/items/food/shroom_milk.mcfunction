summon snowball ~ ~ ~ {Motion:[0.0,4.0,0.0],Tags:["mt.magic_shroom"],Item:{id:"minecraft:red_mushroom",count:1}}

ride @s mount @e[type=snowball,tag=mt.magic_shroom,distance=..1,limit=1]

tellraw @s ["",{"text":"ВОСКРЕСНИ СНОВА, РАДИ БОГА НЕ НАЖИМАЙ SHIFT, О БОЖЕ, О НЕТ!","color":"red"}]

advancement revoke @s only mt:items/food/shroom_milk