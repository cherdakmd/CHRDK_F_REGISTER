advancement revoke @s only mt:mechanics/charm/legendary

advancement revoke @s only mt:mechanics/charm/timer
scoreboard players add @s mt.luck 600
title @s actionbar {"color":"gray","text":"Легендарный оберег активирован!"}
playsound minecraft:ui.toast.challenge_complete ambient @a[distance=..7] ~ ~ ~0.5 0 1