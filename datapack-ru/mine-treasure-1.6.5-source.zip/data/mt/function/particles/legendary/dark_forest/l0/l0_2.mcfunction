execute if score @s mt.plot matches 16 run function mt:particles/legendary/dark_forest/frames/f16
execute if score @s mt.plot matches 17 run function mt:particles/legendary/dark_forest/frames/f17
execute if score @s mt.plot matches 18 run function mt:particles/legendary/dark_forest/frames/f18
execute if score @s mt.plot matches 19 run function mt:particles/legendary/dark_forest/frames/f19
execute if score @s mt.plot matches 20 run function mt:particles/legendary/dark_forest/frames/f20
execute if score @s mt.plot matches 21 run function mt:particles/legendary/dark_forest/frames/f21
execute if score @s mt.plot matches 22 run function mt:particles/legendary/dark_forest/frames/f22
execute if score @s mt.plot matches 23 run function mt:particles/legendary/dark_forest/frames/f23
