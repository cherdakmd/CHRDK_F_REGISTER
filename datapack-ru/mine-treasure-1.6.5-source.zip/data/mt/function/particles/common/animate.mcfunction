execute if score @s mt.plot matches 2 run particle minecraft:campfire_cosy_smoke ~ ~ ~ 0 0 0 0.01 20 force
execute if score @s mt.plot matches 0 run function mt:particles/common/frames/f0
execute if score @s mt.plot matches 1 run function mt:particles/common/frames/f1
execute if score @s mt.plot matches 2 run function mt:particles/common/frames/f2
execute if score @s mt.plot matches 3 run function mt:particles/common/frames/f3
execute if score @s mt.plot matches 4 run function mt:particles/common/frames/f4
execute if score @s mt.plot matches 5 run function mt:particles/common/frames/f5
execute if score @s mt.plot matches 6 run function mt:particles/common/frames/f6
execute if score @s mt.plot matches 7 run function mt:particles/common/frames/f7
execute if score @s mt.plot matches 8 run function mt:particles/common/frames/f8
execute if score @s mt.plot matches 9 run function mt:particles/common/frames/f9
execute if score @s mt.plot matches 10 run function mt:particles/common/frames/f10
execute if score @s mt.plot matches 11 run function mt:particles/common/frames/f11
execute if score @s mt.plot matches 12 run function mt:particles/common/frames/f12
execute if score @s mt.plot matches 13 run function mt:particles/common/frames/f13
execute if score @s mt.plot matches 14 run function mt:particles/common/frames/f14
execute if score @s mt.plot matches 15 run particle firework ~ ~ ~ 0 0 0 0.01 3 force

execute if score @s mt.plot matches 14 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.1 0.3 0.2
execute if score @s mt.plot matches 12 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.2 0.6 0.4
execute if score @s mt.plot matches 10 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.3 0.9 0.6
execute if score @s mt.plot matches 8 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.4 1.2 0.8
execute if score @s mt.plot matches 6 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.5 1.5 1
execute if score @s mt.plot matches 4 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.6 1.8 1
execute if score @s mt.plot matches 2 run playsound minecraft:block.note_block.harp master @a[distance=..10] ~ ~ ~ 0.7 2 1

execute at @s[tag=mt.badlands,scores={mt.plot=1}] run function mt:treasure/biomes/badlands/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.basalt_deltas,scores={mt.plot=1}] run function mt:treasure/biomes/basalt_deltas/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.crimson_forest,scores={mt.plot=1}] run function mt:treasure/biomes/crimson_forest/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.dark_forest,scores={mt.plot=1}] run function mt:treasure/biomes/dark_forest/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.deep_dark,scores={mt.plot=1}] run function mt:treasure/biomes/deep_dark/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.default,scores={mt.plot=1}] run function mt:treasure/biomes/default/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.desert,scores={mt.plot=1}] run function mt:treasure/biomes/desert/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.dripstone,scores={mt.plot=1}] run function mt:treasure/biomes/dripstone/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.default_end,scores={mt.plot=1}] run function mt:treasure/biomes/default_end/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.flower,scores={mt.plot=1}] run function mt:treasure/biomes/flower/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.ice,scores={mt.plot=1}] run function mt:treasure/biomes/ice/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.jungle,scores={mt.plot=1}] run function mt:treasure/biomes/jungle/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.lush_cave,scores={mt.plot=1}] run function mt:treasure/biomes/lush_caves/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.mountain,scores={mt.plot=1}] run function mt:treasure/biomes/mountain/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.mushroom,scores={mt.plot=1}] run function mt:treasure/biomes/mushroom/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.default_nether,scores={mt.plot=1}] run function mt:treasure/biomes/default_nether/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.ocean,scores={mt.plot=1}] run function mt:treasure/biomes/ocean/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.savanna,scores={mt.plot=1}] run function mt:treasure/biomes/savanna/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.soul_valley,scores={mt.plot=1}] run function mt:treasure/biomes/soul_valley/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.swamp,scores={mt.plot=1}] run function mt:treasure/biomes/swamp/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.taiga,scores={mt.plot=1}] run function mt:treasure/biomes/taiga/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.warped_forest,scores={mt.plot=1}] run function mt:treasure/biomes/warped_forest/common with entity @s equipment.feet.components."minecraft:custom_data"
execute at @s[tag=mt.wind,scores={mt.plot=1}] run function mt:treasure/biomes/wind/common with entity @s equipment.feet.components."minecraft:custom_data"

scoreboard players remove @s mt.plot 1