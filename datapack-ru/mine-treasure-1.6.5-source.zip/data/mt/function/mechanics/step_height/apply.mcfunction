tag @s add mt.step_height
attribute @s minecraft:step_height modifier add mt.step 1 add_value

execute store result storage mt:step_height duration int 0.05 run data get entity @s active_effects[{id:"minecraft:unluck"}]."duration"

playsound minecraft:entity.goat.screaming.milk player @s ~ ~ ~ 1 0

effect clear @s unluck

function mt:mechanics/step_height/apply_time with storage mt:step_height

advancement revoke @s only mt:mechanics/step_height/timer
advancement revoke @s only mt:mechanics/step_height/apply