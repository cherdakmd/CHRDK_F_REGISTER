advancement revoke @s only mt:mechanics/milk

function mt:mechanics/big/over
function mt:mechanics/small/over
function mt:mechanics/step_height/over
function mt:mechanics/light/over
function mt:mechanics/reach/over